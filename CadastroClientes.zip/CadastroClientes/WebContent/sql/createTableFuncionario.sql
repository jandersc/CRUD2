-- Script para criar da tabela funcionario
CREATE TABLE funcionario(
  matricula bigint NOT NULL,  
  nome character varying(255),
  telefone character varying(255),  
  email character varying(255),
  datacadastro date,
  CONSTRAINT funcionario_pk PRIMARY KEY (matricula)
);