package com.capgemini.treinamento.business;

import java.util.List;

import com.capgemini.treinamento.dao.EmpresaDAO;
import com.capgemini.treinamento.dao.FuncionarioDAO;
import com.capgemini.treinamento.entidade.Empresa;
import com.capgemini.treinamento.entidade.Funcionario;

/**
 * Classe que possui as regras de negocio relacionadas a Entidade Funcionario
 * 
 * @author silvio
 *
 */
public class EmpresaBusiness {
	private EmpresaDAO empresaDAO;

	public EmpresaBusiness() {
		empresaDAO = new EmpresaDAO();
	}

	public void alterar(Empresa empresa) {
		if(empresaDAO.existe(empresa) == true ){
		empresaDAO.alterar(empresa);
		}
		
	}

	public void inserir(Empresa empresa) {
		empresaDAO.inserir(empresa);
	}

	public void excluir(Empresa empresa) {
		empresaDAO.excluir(empresa);
	}

	public Empresa consultar(Empresa empresa) {
		return empresaDAO.consultar(empresa);
	}

	public List<Empresa> listar() {
		return empresaDAO.listar();
	}

	
	public boolean existe(Empresa empresa) {
		return empresaDAO.existe(empresa);
	}



}
