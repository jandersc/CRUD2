package com.capgemini.treinamento.business;

import java.util.List;

import com.capgemini.treinamento.dao.FuncionarioDAO;
import com.capgemini.treinamento.entidade.Funcionario;

/**
 * Classe que possui as regras de negocio relacionadas a Entidade Funcionario
 * 
 * @author silvio
 *
 */
public class FuncionarioBusiness {
	private FuncionarioDAO funcionarioDao;

	public FuncionarioBusiness() {
		funcionarioDao = new FuncionarioDAO();
	}

	public void alterar(Funcionario funcionario) {
		if(funcionarioDao.existe(funcionario) == true ){
		funcionarioDao.alterar(funcionario);
		}
		
	}

	public void inserir(Funcionario funcionario) {
		funcionarioDao.inserir(funcionario);
	}

	public void excluir(Funcionario funcionario) {
		funcionarioDao.excluir(funcionario);
	}

	public Funcionario consultar(Funcionario funcionario) {
		return funcionarioDao.consultar(funcionario);
	}

	public List<Funcionario> listar() {
		return funcionarioDao.listar();
	}


	public boolean existe(Funcionario funcionario) {
		return funcionarioDao.existe(funcionario);
	}

	public List<Funcionario> listarJoin() {
		return funcionarioDao.listarJoin();
	}

}
