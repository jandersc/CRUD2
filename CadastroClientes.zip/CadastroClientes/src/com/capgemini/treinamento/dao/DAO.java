package com.capgemini.treinamento.dao;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

import org.apache.derby.client.am.SqlException;

import com.capgemini.treinamento.exception.AmbienteException;
import com.capgemini.treinamento.exception.CloseSQLOperationsException;

/**
 * Classe abstrata responsavel por estabelecer a conex�o com o Banco de dados.
 * Essa classe ser� herdada por outras classes de persist�ncia de dados.
 * 
 */
public abstract class DAO {
	protected Connection getConexao() {
		Connection conexao = null;

		String usuario = "postgres";
		String senha = "postgres";
		String banco = "postgres";

		try {

			/** Exemplo de URL e drive para conexao com banco PostgreSQL */
			
			Class.forName("org.postgresql.Driver");
			conexao = DriverManager.getConnection("jdbc:postgresql://localhost:5432/" + banco,
							usuario, senha);
		

			/*** Exemplo de URL e drive para conexão com banco Apache Derby */
			/*Class.forName("org.apache.derby.jdbc.ClientDriver").newInstance();
			conexao = DriverManager.getConnection(
					"jdbc:derby://localhost:1527/" + banco, usuario, senha);*/

		} catch (Exception e) {
			//TODO Incluir log e trocar mensagem por uma key
			throw new AmbienteException("Falha ao carregar o driver de banco", e);
		}
		return conexao;
	}
	
	protected void close(ResultSet resultSet, Statement statement, Connection connection){
		try {
			if (statement != null){
				statement.close();
			}
			if (resultSet != null){
				resultSet.close();
			}
			if (connection != null){
				connection.close();
			}
		} catch (SQLException e) {
			//TODO Incluir log e trocar mensagem por uma key
			throw new CloseSQLOperationsException("Falha ao fechar recursos relacionados ao banco", e); 
		}
	}
}