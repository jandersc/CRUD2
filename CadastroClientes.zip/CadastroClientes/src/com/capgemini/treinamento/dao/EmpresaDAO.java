package com.capgemini.treinamento.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;

import com.capgemini.treinamento.entidade.Empresa;
import com.capgemini.treinamento.entidade.Funcionario;
import com.capgemini.treinamento.exception.AmbienteException;

/**
 * 
 * Classe de Persist�ncia de dados dos objetos de Funcionario � "filha" da
 * Classe DAO.
 *
 */

public class EmpresaDAO extends DAO {

	public void alterar(Empresa empresa) {
		Connection conn = null;
		PreparedStatement stat = null;
		try {
			conn = getConexao();
			stat = conn.prepareStatement(
					"UPDATE empresa SET nomeempresa = ?, cnpjempresa = ? WHERE cnpjempresa = ?");
			stat.setString(1, empresa.getNome());
			stat.setLong(2, empresa.getCnpjEmpresa());
			stat.setLong(3, empresa.getCnpjEmpresa());
			stat.execute();
		} catch (Exception e) {
			throw new AmbienteException(e);
		} finally {
			close(null, stat, conn);
		}
	}

	public void excluir(Empresa empresa) {
		Connection conn = null;
		PreparedStatement stat = null;
		try {
			conn = getConexao();
			stat = conn.prepareStatement("DELETE FROM empresa WHERE cnpjempresa = ?");
			stat.setLong(1, empresa.getCnpjEmpresa());
			stat.execute();
		} catch (Exception e) {
			throw new AmbienteException(e);
		} finally {
			close(null, stat, conn);
		}
	}

	public boolean existe(Empresa empresa) {
		boolean achou = false;
		Connection conn = null;
		PreparedStatement stat = null;
		try {
			conn = getConexao();
			stat = conn.prepareStatement("SELECT * FROM empresa WHERE cnpjempresa = ?");
			stat.setLong(1, empresa.getCnpjEmpresa());
			ResultSet rs = stat.executeQuery();
			if (rs.next()) {
				achou = true;
			}
		} catch (Exception e) {
			throw new AmbienteException(e);
		} finally {
			close(null, stat, conn);
		}
		return achou;
	}
	

	public void inserir(Empresa empresa) {
		Connection conn = null;
		PreparedStatement stat = null;
		try {
			conn = getConexao();
			stat = conn.prepareStatement(
					"INSERT INTO empresa (nomeempresa, cnpjEmpresa) VALUES	(?,?)");
			stat.setString(1, empresa.getNome());
			stat.setLong(2, empresa.getCnpjEmpresa());
			stat.execute();
		} catch (Exception e) {
			throw new AmbienteException(e);
		} finally {
			close(null, stat, conn);
		}
	}

	public List<Empresa> listar() {
		List<Empresa> lista = new ArrayList<>();
		Connection conn = null;
		Statement stat = null;
		ResultSet rs = null;
		
		try {
			conn = getConexao();
			stat = conn.createStatement();
			rs = stat.executeQuery("select* from empresa");
			while (rs.next()) {
				Empresa empresa = new Empresa();
				empresa.setNome(rs.getString("nomeempresa"));
				empresa.setCnpjEmpresa(rs.getLong("cnpjEmpresa"));
				lista.add(empresa);
			}
		} catch (Exception e) {
			throw new AmbienteException(e);
		} finally {
			close(rs, stat, conn);
		}
		return lista;
	}

	
	public Empresa consultar(Empresa empresa) {
		Connection conn = null;
		PreparedStatement stat = null;
		ResultSet rs =  null;
		try {
			conn = getConexao();
			stat = conn.prepareStatement("SELECT * FROM empresa WHERE cnpjempresa =	?");
			stat.setLong(1, empresa.getCnpjEmpresa());
			rs = stat.executeQuery();
			if (rs.next()) 
				empresa.setNome(rs.getString("nomeempresa"));
				empresa.setCnpjEmpresa(rs.getLong("cnpjEmpresa"));
			
		} catch (Exception e) {
			throw new AmbienteException(e);
		} finally {
			close(rs, stat, conn);
		}
		return empresa;
	}
}