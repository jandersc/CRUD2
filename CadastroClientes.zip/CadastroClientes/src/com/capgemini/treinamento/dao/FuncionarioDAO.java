package com.capgemini.treinamento.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;

import com.capgemini.treinamento.entidade.Empresa;
import com.capgemini.treinamento.entidade.Funcionario;
import com.capgemini.treinamento.exception.AmbienteException;

/**
 * 
 * Classe de Persist�ncia de dados dos objetos de Funcionario � "filha" da
 * Classe DAO.
 *
 */

public class FuncionarioDAO extends DAO {

	public void alterar(Funcionario funcionario) {
		Connection conn = null;
		PreparedStatement stat = null;
		try {
			conn = getConexao();
			stat = conn.prepareStatement(
					"UPDATE funcionario SET nome = ?, telefone = ?, email = ?, datacadastro = ?, cnpjEmpresa? WHERE matricula = ?");
			stat.setString(1, funcionario.getNome());
			stat.setString(2, funcionario.getTelefone());
			stat.setString(3, funcionario.getEmail());
			stat.setDate(4, new java.sql.Date(funcionario.getDataCadastro().getTime()));
			stat.setLong(5, funcionario.getCnpjEmpresa());
			stat.setLong(6, funcionario.getMatricula());
			stat.execute();
		} catch (Exception e) {
			throw new AmbienteException(e);
		} finally {
			close(null, stat, conn);
		}
	}

	public void excluir(Funcionario funcionario) {
		Connection conn = null;
		PreparedStatement stat = null;
		try {
			conn = getConexao();
			stat = conn.prepareStatement("DELETE FROM funcionario WHERE matricula = ?");
			stat.setLong(1, funcionario.getMatricula());
			stat.execute();
		} catch (Exception e) {
			throw new AmbienteException(e);
		} finally {
			close(null, stat, conn);
		}
	}

	public boolean existe(Funcionario funcionario) {
		boolean achou = false;
		Connection conn = null;
		PreparedStatement stat = null;
		try {
			conn = getConexao();
			stat = conn.prepareStatement("SELECT * FROM funcionario WHERE matricula = ?");
			stat.setLong(1, funcionario.getMatricula());
			ResultSet rs = stat.executeQuery();
			if (rs.next()) {
				achou = true;
			}
		} catch (Exception e) {
			throw new AmbienteException(e);
		} finally {
			close(null, stat, conn);
		}
		return achou;
	}

	public void inserir(Funcionario funcionario) {
		Connection conn = null;
		PreparedStatement stat = null;
		try {
			conn = getConexao();
			stat = conn.prepareStatement(
					"INSERT INTO funcionario (matricula, nome, telefone, email, datacadastro, cnpjEmpresa) VALUES	(?,?,?,?,?,?)");
			stat.setLong(1, funcionario.getMatricula());
			stat.setString(2, funcionario.getNome());
			stat.setString(3, funcionario.getTelefone());
			stat.setString(4, funcionario.getEmail());
			stat.setDate(5, new java.sql.Date(funcionario.getDataCadastro().getTime()));
			stat.setLong(6, funcionario.getCnpjEmpresa());
			stat.execute();
		} catch (Exception e) {
			throw new AmbienteException(e);
		} finally {
			close(null, stat, conn);
		}
	}

	public List<Funcionario> listar() {
		List<Funcionario> lista = new ArrayList<>();
		Connection conn = null;
		Statement stat = null;
		ResultSet rs = null;

		try {
			conn = getConexao();
			stat = conn.createStatement();
			rs = stat.executeQuery("select* from funcionario");
			while (rs.next()) {
				Funcionario funcionario = new Funcionario();
				funcionario.setMatricula(rs.getLong("matricula"));
				funcionario.setNome(rs.getString("nome"));
				funcionario.setTelefone(rs.getString("telefone"));
				funcionario.setEmail(rs.getString("email"));
				funcionario.setDataCadastro(new java.util.Date(rs.getDate("datacadastro").getTime()));
				funcionario.setCnpjEmpresa(rs.getLong("cnpjEmpresa"));
				lista.add(funcionario);

			}
		} catch (Exception e) {
			throw new AmbienteException(e);
		} finally {
			close(rs, stat, conn);
		}
		return lista;
	}

	public List<Funcionario> listarJoin() {
		List<Funcionario> listaJoin = new ArrayList<>();
		Connection conn = null;
		Statement stat = null;
		ResultSet rs = null;

		try {
			conn = getConexao();
			stat = conn.createStatement();
			rs = stat.executeQuery("select f.matricula, f.nome, f.telefone, f.email, f.datacadastro, "
					+ "e.nomeempresa from funcionario f inner join empresa e on f.cnpjempresa = e.cnpjempresa "
					+ "order by f.matricula");
			while (rs.next()) {
				Funcionario funcionario = new Funcionario();
				//Empresa empresa = new Empresa();
				funcionario.setMatricula(rs.getLong("matricula"));
				funcionario.setNome(rs.getString("nome"));
				funcionario.setTelefone(rs.getString("telefone"));
				funcionario.setEmail(rs.getString("email"));
				funcionario.setDataCadastro(new java.util.Date(rs.getDate("datacadastro").getTime()));
				funcionario.setNomeEmpresa(rs.getString("nomeempresa"));
				listaJoin.add(funcionario);

			}
		} catch (Exception e) {
			throw new AmbienteException(e);
		} finally {
			close(rs, stat, conn);
		}
		return listaJoin;
	}

	public Funcionario consultar(Funcionario funcionario) {
		Connection conn = null;
		PreparedStatement stat = null;
		ResultSet rs = null;
		try {
			conn = getConexao();
			stat = conn.prepareStatement("select* from funcionario where matricula = ?");
			stat.setLong(1,funcionario.getMatricula());
			rs = stat.executeQuery();
			if (rs.next()) {
				funcionario.setMatricula(rs.getLong("matricula"));
				funcionario.setNome(rs.getString("nome"));
				funcionario.setTelefone(rs.getString("telefone"));
				funcionario.setEmail(rs.getString("email"));
				funcionario.setDataCadastro(new java.util.Date(rs.getDate("datacadastro").getTime()));
				funcionario.setCnpjEmpresa(rs.getLong("cnpjEmpresa"));
			}
		} catch (Exception e) {
			throw new AmbienteException(e);
		} finally {
			close(rs, stat, conn);
		}
		return funcionario;
	}
}