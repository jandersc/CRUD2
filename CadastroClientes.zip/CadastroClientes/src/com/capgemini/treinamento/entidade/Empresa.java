/**
 * 
 */
package com.capgemini.treinamento.entidade;

import java.io.Serializable;

/**
 * @author jander.cerqueira
 *
 */
public class Empresa implements Serializable {

	private static final long serialVersionUID = 7236692026818410593L;

	private String nome;

	private Long cnpjEmpresa;

	public Empresa() {
	}

	public Empresa(Long cnpjEmpresa) {
		super();
		this.cnpjEmpresa = cnpjEmpresa;
	}

	public Empresa(Long cnpjEmpresa, String nome) {
		super();
		this.cnpjEmpresa = cnpjEmpresa;
		this.nome = nome;
	}

	public String getNome() {
		return nome;
	}

	public void setNome(String nome) {
		this.nome = nome;
	}

	public Long getCnpjEmpresa() {
		return cnpjEmpresa;
	}

	public void setCnpjEmpresa(Long cnpjEmpresa) {
		this.cnpjEmpresa = cnpjEmpresa;
	}

}
