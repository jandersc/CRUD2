package com.capgemini.treinamento.entidade;

import java.io.Serializable;
import java.util.Date;

/**
 * 
 * Classe de entidade que possui os atributos do funcionario
 *
 */
public class Funcionario implements Serializable {
	private static final long serialVersionUID = -309513637403441918L;

	private Long matricula;

	private String nome;

	private String telefone;

	private String email;

	private Date dataCadastro;
	
	private Long cnpjEmpresa;
	
	private String nomeEmpresa;

	public Funcionario() {
	}

	public Funcionario(Long matricula) {
		super();
		this.matricula = matricula;
	}

	public Funcionario(Long matricula, String nome) {
		super();
		this.matricula = matricula;
		this.nome = nome;
	}

	public Date getDataCadastro() {
		return dataCadastro;
	}

	public String getEmail() {
		return email;
	}

	public Long getMatricula() {
		return matricula;
	}

	public String getNome() {
		return nome;
	}

	public String getTelefone() {
		return telefone;
	}

	public void setDataCadastro(Date dataCadastro) {
		this.dataCadastro = dataCadastro;
	}

	public void setEmail(String email) {
		this.email = email;
	}

	public void setMatricula(Long matricula) {
		this.matricula = matricula;
	}

	public void setNome(String nome) {
		this.nome = nome;
	}

	public void setTelefone(String telefone) {
		this.telefone = telefone;
	}
	
	public Long getCnpjEmpresa() {
		return cnpjEmpresa;
	}

	public void setCnpjEmpresa(Long cnpjEmpresa) {
		this.cnpjEmpresa = cnpjEmpresa;
	}

	
	public String getNomeEmpresa() {
		return nomeEmpresa;
	}

	public void setNomeEmpresa(String nomeEMpresa) {
		this.nomeEmpresa = nomeEMpresa;
	}

	@Override
	public String toString() {
		return "Funcionario [matricula=" + matricula + ", nome=" + nome
				+ ", telefone=" + telefone + ", email=" + email
				+ ", dataCadastro=" + dataCadastro + "]";
	}
}