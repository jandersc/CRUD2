package com.capgemini.treinamento.exception;

public class AmbienteException extends RuntimeException {

	private static final long serialVersionUID = -3006010207449528066L;
	//TODO Substituir message por uma chave que iterage com ResourceBundleUtil

	public AmbienteException() {
		super();
	}

	public AmbienteException(String message, Throwable cause, boolean enableSuppression, boolean writableStackTrace) {
		super(message, cause, enableSuppression, writableStackTrace);
	}

	public AmbienteException(String message, Throwable cause) {
		super(message, cause);
	}

	public AmbienteException(String message) {
		super(message);
	}

	public AmbienteException(Throwable cause) {
		super(cause);
	}
	
	

}
