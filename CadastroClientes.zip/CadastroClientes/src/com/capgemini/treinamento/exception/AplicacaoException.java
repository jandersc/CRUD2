package com.capgemini.treinamento.exception;

public class AplicacaoException extends RuntimeException {

	private static final long serialVersionUID = -8966748672740702583L;
	//TODO Substituir message por uma chave que iterage com ResourceBundleUtil
	
	public AplicacaoException() {
		super();
	}

	public AplicacaoException(String message, Throwable cause, boolean enableSuppression, boolean writableStackTrace) {
		super(message, cause, enableSuppression, writableStackTrace);
	}

	public AplicacaoException(String message, Throwable cause) {
		super(message, cause);
	}

	public AplicacaoException(String message) {
		super(message);
	}

	public AplicacaoException(Throwable cause) {
		super(cause);
	}
	
	

}
