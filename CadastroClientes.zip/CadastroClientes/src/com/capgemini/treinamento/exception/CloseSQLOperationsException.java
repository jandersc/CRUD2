package com.capgemini.treinamento.exception;

public class CloseSQLOperationsException extends AmbienteException {

	private static final long serialVersionUID = 5730411980766544711L;

	public CloseSQLOperationsException() {
		super();
	}

	public CloseSQLOperationsException(String message, Throwable cause, boolean enableSuppression,
			boolean writableStackTrace) {
		super(message, cause, enableSuppression, writableStackTrace);
	}

	public CloseSQLOperationsException(String message, Throwable cause) {
		super(message, cause);
	}

	public CloseSQLOperationsException(String message) {
		super(message);
	}

	public CloseSQLOperationsException(Throwable cause) {
		super(cause);
	}
	
}
