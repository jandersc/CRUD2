/**
 * 
 */
package com.capgemini.treinamento.servlet;

import javax.servlet.http.HttpServlet;

/**
 * @author sijesus
 *
 */
public abstract class ApplicationServlet extends HttpServlet {

	private static final long serialVersionUID = -8966708700180926853L;

}
