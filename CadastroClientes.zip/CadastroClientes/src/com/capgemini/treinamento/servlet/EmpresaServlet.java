package com.capgemini.treinamento.servlet;

import java.io.IOException;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.capgemini.treinamento.business.EmpresaBusiness;
import com.capgemini.treinamento.business.FuncionarioBusiness;
import com.capgemini.treinamento.dao.FuncionarioDAO;
import com.capgemini.treinamento.entidade.Empresa;

@WebServlet("/EmpresaServlet")
public class EmpresaServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;

	protected void doGet(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		doPost(request, response);
	}

	protected void doPost(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		String acao = request.getParameter("acao");
		String destino = "sucessoEmpresa.jsp";
		String mensagem = "";
		


		List<Empresa> lista2 = new ArrayList<>();

		Empresa empresa = new Empresa();
		EmpresaBusiness eb = new EmpresaBusiness();

			try {
				if (!acao.equalsIgnoreCase("Listar")) {
					empresa.setNome(request.getParameter("nome"));
					empresa.setCnpjEmpresa(Long.parseLong(request.getParameter("cnpjEmpresa")));
				}

				if (acao.equalsIgnoreCase("Incluir2")) {
					if (eb.existe(empresa)) {
						mensagem = " ERRO!!! - CNPJ informado j� existe!";
					} else {
						eb.inserir(empresa);
						mensagem = "Empresa Cadastrada com Sucesso!!!";
					}

				}

				if (acao.equalsIgnoreCase("Alterar2")) {
					// Verifica se o funcionario existe no banco de dados
					// Se n�o existir uma mensagem � exibida
					if (eb.existe(empresa) == false) {
						mensagem = "Empresa n�o localizada!";
					} else {
						eb.alterar(empresa);
						mensagem = "Empresa Alterada com Sucesso!!!";
					}
				}

				if (acao.equalsIgnoreCase("Excluir2")) {
					// Verifica se o funcionario existe no banco de dados
					// Se n�o existir uma mensagem � exibida
					if (eb.existe(empresa) == false) {
						mensagem = "Empresa n�o localizado!";
					} else {
						eb.excluir(empresa);
						
					}
				}

				if (acao.equalsIgnoreCase("Consultar2")) {
					request.setAttribute("empresa", empresa);
					empresa = eb.consultar(empresa);
					destino = "empresa.jsp";
				}

			} catch (Exception e) {
				mensagem += e.getMessage();
				destino = "erro.jsp";
				e.printStackTrace();
			}

		 			
			// Se a mensagem estiver vazia significa que houve sucesso!
			// Sen�o ser�o exibida a tela de erro do sistema.
			/*if (mensagem.length() == 0) {
				mensagem = "Empresa Cadastrada com sucesso!";
			} else {
				// destino = "erro.jsp";
			}*/

			// VERIFICAR A LISTAGEM
			lista2 = eb.listar();
			request.setAttribute("listaEmpresa", lista2);
			request.setAttribute("mensagem", mensagem);

			// O sistema � direcionado para a p�gina
			// sucesso.jsp Se tudo ocorreu bem
			// erro.jsp se houver algum problema.
			RequestDispatcher rd = request.getRequestDispatcher(destino);
			rd.forward(request, response);

		
	}
}
