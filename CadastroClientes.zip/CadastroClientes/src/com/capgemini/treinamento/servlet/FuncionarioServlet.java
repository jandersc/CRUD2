package com.capgemini.treinamento.servlet;

import java.io.IOException;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.capgemini.treinamento.business.FuncionarioBusiness;
import com.capgemini.treinamento.dao.FuncionarioDAO;
import com.capgemini.treinamento.entidade.Funcionario;

@WebServlet("/FuncionarioServlet")
public class FuncionarioServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;

	protected void doGet(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		doPost(request, response);
	}

	protected void doPost(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		String acao = request.getParameter("acao");
		String destino = "sucesso.jsp";
		String mensagem = "";

		List<Funcionario> lista = new ArrayList<>();

		Funcionario funcionario = new Funcionario();
		// FuncionarioDAO dao = new FuncionarioDAO();
		FuncionarioBusiness fb = new FuncionarioBusiness();


			try {
				
				if (!acao.equalsIgnoreCase("Listar")) {
				funcionario.setMatricula(Long.parseLong(request.getParameter("matricula")));
				funcionario.setNome(request.getParameter("nome"));
				funcionario.setTelefone(request.getParameter("telefone"));
				funcionario.setEmail(request.getParameter("email"));
				// Faz a leitura da data de cadastro. Caso ocorra um erro de
				// formata��o
				// o sistema utilizar� a data atual
				try {
					DateFormat df = new SimpleDateFormat("dd/MM/yyyy");
					funcionario.setDataCadastro(df.parse(request.getParameter("dataCadastro")));
				} catch (Exception e) {
					funcionario.setDataCadastro(new Date());
				}
				funcionario.setCnpjEmpresa(Long.parseLong(request.getParameter("cnpjEmpresa")));

				}
				
				if (acao.equalsIgnoreCase("Incluir")) {
					// Verifica se a matr�cula informada j�o existe no Banco
					// de
					// Dados
					// Se existir enviar uma mensagem sen�o faz a inclus�o
					if (fb.existe(funcionario)) {
						mensagem = "Matr�cula informada j� existe!";
					} else {
						fb.inserir(funcionario);
					}

				}

				if (acao.equalsIgnoreCase("Alterar")) {
					// Verifica se o funcionario existe no banco de dados
					// Se n�o existir uma mensagem � exibida
					if (fb.existe(funcionario) == false) {
						mensagem = "Funcionario n�o localizado!";
					} else {
						fb.alterar(funcionario);
					}
				}

				if (acao.equalsIgnoreCase("Excluir")) {
					// Verifica se o funcionario existe no banco de dados
					// Se n�o existir uma mensagem � exibida
					if (fb.existe(funcionario) == false) {
						mensagem = "Funcionario n�o localizado!";
					} else {
						fb.excluir(funcionario);
					}

				}

				if (acao.equalsIgnoreCase("Consultar")) {
					request.setAttribute("funcionario", funcionario);
					funcionario = fb.consultar(funcionario);
					destino = "funcionario.jsp";
				}

			} catch (Exception e) {
				mensagem += e.getMessage();
				destino = "erro.jsp";
				e.printStackTrace();

			}

			// Se a mensagem estiver vazia significa que houve sucesso!
			// Sen�o ser�o exibida a tela de erro do sistema.
			/*
			 * if (mensagem.length() == 0) { mensagem =
			 * "Funcionario Cadastrado com sucesso!"; } else { //destino =
			 * "erro.jsp"; }
			 */

			// Lista todos os registros existente no Banco de Dados
			lista = fb.listarJoin();
			request.setAttribute("listaFuncionario", lista);
			request.setAttribute("mensagem", mensagem);

			// O sistema � direcionado para a p�gina
			// sucesso.jsp Se tudo ocorreu bem
			// erro.jsp se houver algum problema.
			RequestDispatcher rd = request.getRequestDispatcher(destino);
			rd.forward(request, response);
		}
	
}
