/**
 * 
 */
package com.capgemini.treinamento.servlet;

import java.io.IOException;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.capgemini.treinamento.business.FuncionarioBusiness;
import com.capgemini.treinamento.entidade.Funcionario;

/**
 * @author jander.cerqueira
 *
 */

@WebServlet("/LoginServlet")
public class LoginServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;

	protected void doGet(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		doPost(request, response);
	}

	protected void doPost(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		String acao = request.getParameter("acao");
		String destino = "sucesso.jsp";
		String mensagem = "";
		String senha = request.getParameter("senha");

		Funcionario funcionario = new Funcionario();
		FuncionarioBusiness fb = new FuncionarioBusiness();

		if ("Login".equalsIgnoreCase(acao)) {

			try {
				funcionario.setMatricula(Long.parseLong(request.getParameter("login")));
				if (fb.existe(funcionario) && "cap".equalsIgnoreCase(senha)) {
					request.setAttribute("funcionario", funcionario);
					funcionario = fb.consultar(funcionario);
					mensagem = "Usu�rio "+funcionario.getNome()+ " Logado";
					destino = "menu.jsp";
				} else {
					mensagem = "Usu�rio ou senha inv�lidos!!!";
					destino = "login.jsp";
				}
			} catch (NumberFormatException e) {
				mensagem= "Caractere digitado no lugar da matr�cula!!!";
				destino = "erro.jsp";
				e.printStackTrace();
			}
			
			request.setAttribute("mensagem", mensagem);
			RequestDispatcher rd = request.getRequestDispatcher(destino);
			rd.forward(request, response);
		}
	}
}
