package com.capgemini.treinamento.util;

import java.util.Locale;
import java.util.ResourceBundle;

public final class ResourceBundleUtil {
	
	private ResourceBundleUtil(){
	}
	
	public final static String LOCALE_DEFAULT = "pt_br";
	public final static String BUNDLE_MENSAGENS = "mensagens";
	public final static String BUNDLE_LABELS = "labels";
	
	public String getValue(String key){
		return ResourceBundle.getBundle(BUNDLE_MENSAGENS).getString(key);
	}
	
	public String getValue(String key, Locale locale){
		return ResourceBundle.getBundle(BUNDLE_MENSAGENS, locale).getString(key);
	}

}
